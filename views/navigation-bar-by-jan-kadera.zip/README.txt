A Pen created at CodePen.io. You can find this one at http://codepen.io/katydecorah/pen/HEgwl.

 Give it a hover! Inspired by: Navigation Bar by Jan Kaděra http://dribbble.com/shots/1267103-Navigation-Bar